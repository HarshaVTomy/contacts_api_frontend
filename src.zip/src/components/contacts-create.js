// ContactsCreate.js
import React from 'react';


const ContactsCreate = () => {
  return(
    <>
     <div className="App">
      <h2>Create Contact</h2>
      {/* Add code for creating a new contact here */}
    </div>
    </>
  )
}
export default ContactsCreate;
