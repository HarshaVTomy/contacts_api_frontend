// ContactsList.js
import React from 'react';
import { Card, Button } from 'react-bootstrap';
import axios from 'axios';
const ContactsList = () =>{
  const [name, setName]= React.useState("");
  React.useEffect(() => {
    axios.get('https://dog.ceo/api/breeds/image/random')
    .then(response => {
      this.setState({ imageURL: response.data.message });
    })
    .catch(error => {
      console.log(error);
    });
  },[])
  //alert(name);
  return (
    <div className="App">
      <h2>Contacts List</h2>
      <Card>
        <Card.Body>
          <Card.Title>Contact Name</Card.Title>
          <Card.Text>
            Contact details here...
          </Card.Text>
          <input onChange={(e) => setName(e.target.value)} />
          <Button variant="primary">Edit</Button>
          <Button variant="danger">Delete</Button>
        </Card.Body>
      </Card>
    </div>
  );
}

export default ContactsList;
