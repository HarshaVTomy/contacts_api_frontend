// ContactsDetail.js
import React from 'react';


const ContactsDetail = () => {
  return (
    <div className="App">
      <h2>Contact Detail</h2>
      {/* Add code for displaying contact detail here */}
    </div>
  );
}
export default ContactsDetail;
